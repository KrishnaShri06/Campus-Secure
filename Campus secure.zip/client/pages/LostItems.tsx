import PlaceholderPage from "@/components/PlaceholderPage";

export default function LostItems() {
  return (
    <PlaceholderPage
      title="Browse Lost Items"
      description="Search through reported lost items and see if your belongings are waiting for you."
      icon="🔍"
    />
  );
}
