import { useState } from "react";
import Loader from "@/components/Loader";
import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import FoundItemsGrid from "@/components/FoundItemsGrid";
import TeamSection from "@/components/TeamSection";

export default function Index() {
  const [isLoading, setIsLoading] = useState(true);

  const handleLoaderComplete = () => {
    setIsLoading(false);
  };

  if (isLoading) {
    return <Loader onComplete={handleLoaderComplete} />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="pt-16">
        <Hero />
        <FoundItemsGrid />
        <TeamSection />
      </main>
    </div>
  );
}
