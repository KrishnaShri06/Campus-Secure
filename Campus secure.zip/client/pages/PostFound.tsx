import PlaceholderPage from "@/components/PlaceholderPage";

export default function PostFound() {
  return (
    <PlaceholderPage
      title="Report Found Item"
      description="Help reunite students with their belongings by reporting items you've found around campus."
      icon="📋"
    />
  );
}
