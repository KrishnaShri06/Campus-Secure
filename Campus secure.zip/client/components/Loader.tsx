import { useEffect, useState } from "react";

interface LoaderProps {
  onComplete: () => void;
}

export default function Loader({ onComplete }: LoaderProps) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onComplete, 500); // Allow fade out animation
    }, 3000); // Show loader for 3 seconds

    return () => clearTimeout(timer);
  }, [onComplete]);

  if (!isVisible) {
    return (
      <div className="fixed inset-0 bg-background flex items-center justify-center z-50 animate-fade-out opacity-0 transition-opacity duration-500">
        <div className="text-center text-foreground">
          <div className="mb-8">
            <div className="relative">
              <div className="w-20 h-20 border-4 border-border rounded-full animate-spin">
                <div className="absolute inset-2 border-4 border-brand-orange border-t-transparent rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1s' }}></div>
              </div>
            </div>
          </div>
          <h1 className="text-3xl font-bold mb-4 animate-loader-pulse text-brand-orange">
            Campus Secure
          </h1>
          <p className="text-xl font-medium animate-loader-pulse text-muted-foreground">
            Hang tight… Helping you find your lost things.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-background flex items-center justify-center z-50">
      <div className="text-center text-foreground">
        <div className="mb-8">
          <div className="relative">
            <div className="w-20 h-20 border-4 border-border rounded-full animate-spin">
              <div className="absolute inset-2 border-4 border-brand-orange border-t-transparent rounded-full animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1s' }}></div>
            </div>
          </div>
        </div>
        <h1 className="text-3xl font-bold mb-4 animate-loader-pulse text-brand-orange">
          Campus Secure
        </h1>
        <p className="text-xl font-medium animate-loader-pulse text-muted-foreground">
          Hang tight… Helping you find your lost things.
        </p>
      </div>
    </div>
  );
}
