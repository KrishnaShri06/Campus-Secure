export default function Marquee() {
  const announcements = [
    "Found a keychain? Post it here",
    "Lost your ID card? Check below",
    "New items found in the library",
    "Check the science building for lost electronics",
    "Don't forget to claim your items within 30 days"
  ];

  return (
    <div className="bg-gradient-to-r from-brand-orange to-brand-green text-white py-2 overflow-hidden relative">
      <div className="flex animate-marquee whitespace-nowrap">
        {announcements.map((announcement, index) => (
          <span 
            key={index} 
            className="mx-8 text-sm font-medium"
          >
            📢 {announcement}
          </span>
        ))}
        {/* Duplicate for seamless loop */}
        {announcements.map((announcement, index) => (
          <span 
            key={`duplicate-${index}`} 
            className="mx-8 text-sm font-medium"
          >
            📢 {announcement}
          </span>
        ))}
      </div>
    </div>
  );
}
