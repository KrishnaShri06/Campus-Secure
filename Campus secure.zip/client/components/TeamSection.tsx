import { useState } from "react";

interface TeamMember {
  id: number;
  name: string;
  role: string;
  imageUrl: string;
}

const teamMembers: TeamMember[] = [
  {
    id: 1,
    name: "Krishna Shrivastav",
    role: "FrontEnd Developer",
    imageUrl: "https://cdn.builder.io/api/v1/image/assets%2F6a393caa557c44fb8803dbfe8a08ae5d%2F4e8e5ab323504637ac8c4e450c48a668?format=webp&width=800"
  },
  {
    id: 2,
    name: "Krishnam Shukla", 
    role: "UI/UX Designer",
    imageUrl: "https://images.unsplash.com/photo-1494790108755-2616b2e3c3f9?w=300&h=300&fit=crop&crop=face"
  }
];

export default function TeamSection() {
  const [hoveredMember, setHoveredMember] = useState<number | null>(null);

  return (
    <section className="py-16 px-4 bg-card">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Meet the Developers
          </h2>
          <p className="text-xl text-muted-foreground">
            The team behind Campus Secure
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
          {teamMembers.map((member) => (
            <div key={member.id} className="relative">
              <div
                className="text-center p-8 bg-background border border-border rounded-lg cursor-pointer transition-all duration-300 hover:border-brand-orange hover:shadow-lg flex flex-col justify-center items-start"
                onMouseEnter={() => setHoveredMember(member.id)}
                onMouseLeave={() => setHoveredMember(null)}
              >
                <h3 className="text-2xl font-semibold text-foreground mb-2 hover:text-brand-orange transition-colors">
                  {member.name}
                </h3>
                <p className="text-muted-foreground text-lg">
                  {member.role}
                </p>
                
                {/* Photo pop-up that appears on hover */}
                <div className={`absolute top-full left-1/2 transform -translate-x-1/2 mt-4 z-10 transition-all duration-300 ${
                  hoveredMember === member.id 
                    ? 'opacity-100 translate-y-0 pointer-events-auto' 
                    : 'opacity-0 -translate-y-4 pointer-events-none'
                }`}>
                  <div className="relative">
                    {/* Arrow pointing up */}
                    <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-background border-l border-t border-border rotate-45"></div>
                    
                    {/* Photo container */}
                    <div className="bg-background border border-border rounded-lg p-4 shadow-xl">
                      <img
                        src={member.imageUrl}
                        alt={member.name}
                        className="w-32 h-32 rounded-full object-cover mx-auto"
                      />
                      <p className="text-center mt-3 text-sm text-muted-foreground">
                        {member.name}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-muted-foreground">
            Hover over our names to see our photos!
          </p>
        </div>
      </div>
    </section>
  );
}
