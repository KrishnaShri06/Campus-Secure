import { Link } from "react-router-dom";
import Navigation from "./Navigation";

interface PlaceholderPageProps {
  title: string;
  description: string;
  icon: string;
}

export default function PlaceholderPage({ title, description, icon }: PlaceholderPageProps) {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="pt-20 pb-16">
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <div className="text-6xl mb-8">{icon}</div>
          <h1 className="text-4xl font-bold text-foreground mb-6">{title}</h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">{description}</p>
          
          <div className="bg-card border border-border rounded-lg p-8 mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">
              This page is coming soon!
            </h2>
            <p className="text-muted-foreground mb-6">
              We're working hard to bring you this feature. In the meantime, you can continue exploring the homepage.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/"
                className="bg-brand-orange text-white px-6 py-3 rounded-lg font-medium hover:bg-brand-orange-dark transition-colors"
              >
                Back to Homepage
              </Link>
              <Link
                to="/contact"
                className="border border-border text-foreground px-6 py-3 rounded-lg font-medium hover:bg-card transition-colors"
              >
                Contact Support
              </Link>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
