import { useState } from "react";

interface FoundItem {
  id: string;
  title: string;
  description: string;
  location: string;
  imageUrl: string;
  dateFound: string;
  category: string;
}

// Mock data for demonstration
const mockFoundItems: FoundItem[] = [
  {
    id: "1",
    title: "Blue Backpack",
    description: "Navy blue Jansport backpack with laptop compartment",
    location: "Library - 4th Floor",
    imageUrl: "https://cdn.builder.io/api/v1/image/assets%2F6a393caa557c44fb8803dbfe8a08ae5d%2Fe7d9b6fd13e14576b493b1e44f65ce82",
    dateFound: "2025-08-02",
    category: "Bags"
  },
  {
    id: "2",
    title: "iPhone 13",
    description: "Black iPhone 13 with cracked screen protector",
    location: "Multipurpose Hall",
    imageUrl: "https://cdn.builder.io/api/v1/image/assets%2F6a393caa557c44fb8803dbfe8a08ae5d%2F445c9f6ec8ca487e928751de9bc6c221",
    dateFound: "2025-07-30",
    category: "Electronics"
  },
  {
    id: "3",
    title: "Reading Glasses",
    description: "Round frame glasses in brown case",
    location: "Room 205",
    imageUrl: "https://images.unsplash.com/photo-1574258495973-f010dfbb5371?w=300&h=300&fit=crop",
    dateFound: "2025-07-13",
    category: "Personal Items"
  },
  {
    id: "4",
    title: "Water Bottle",
    description: "Stainless steel Hydro Flask, mint green",
    location: "Boys Common Room",
    imageUrl: "https://cdn.builder.io/api/v1/image/assets%2F6a393caa557c44fb8803dbfe8a08ae5d%2Fa49d17d5cb6b4554bb607770605f379d",
    dateFound: "2025-07-12",
    category: "Personal Items"
  },
  {
    id: "5",
    title: "Notebook",
    description: "Spiral notebook with physics notes",
    location: "Physics Lab",
    imageUrl: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=300&h=300&fit=crop",
    dateFound: "2025-07-11",
    category: "Academic"
  },
  {
    id: "6",
    title: "Umbrella",
    description: "Black colour with gold handle",
    location: "Room n0: 608",
    imageUrl: "https://cdn.builder.io/api/v1/image/assets%2F6a393caa557c44fb8803dbfe8a08ae5d%2Fc804e07997a64f2dbd027abfc32cd225",
    dateFound: "2025-07-10",
    category: "Keys"
  }
];

export default function FoundItemsGrid() {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);

  return (
    <section className="py-16 px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Recently Found Items
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Browse through items that have been found around campus.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockFoundItems.map((item) => (
            <div
              key={item.id}
              className="group relative bg-card border border-border rounded-lg overflow-hidden transition-all duration-300 hover:border-brand-orange cursor-pointer"
              onMouseEnter={() => setHoveredItem(item.id)}
              onMouseLeave={() => setHoveredItem(null)}
            >
              <div className="relative overflow-hidden">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {/* Category Badge */}
                <div className="absolute top-3 left-3">
                  <span className="px-2 py-1 bg-brand-orange text-white text-xs font-medium rounded">
                    {item.category}
                  </span>
                </div>

                {/* Hover overlay with details */}
                <div className={`absolute inset-0 flex items-center justify-center transition-all duration-300 ${
                  hoveredItem === item.id ? 'opacity-100' : 'opacity-0'
                }`}>
                  <button className="bg-brand-orange text-white px-6 py-2 rounded-lg font-medium hover:bg-brand-orange-dark transition-colors">
                    View Details
                  </button>
                </div>
              </div>

              <div className="p-4">
                <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-brand-orange transition-colors">
                  {item.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                  {item.description}
                </p>
                
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">
                    📍 {item.location}
                  </span>
                  <span className="text-brand-orange font-medium">
                    {new Date(item.dateFound).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-brand-orange hover:bg-brand-orange-dark text-white px-8 py-3 rounded-lg text-lg font-semibold transition-colors">
            View All Items
          </button>
        </div>
      </div>
    </section>
  );
}
