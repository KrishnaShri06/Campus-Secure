import { useState } from "react";
import { Link } from "react-router-dom";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 bg-background/95 backdrop-blur-sm border-b border-border z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link
              to="/"
              className="flex items-center space-x-2 text-xl font-bold text-brand-orange hover:text-brand-orange-dark transition-colors"
              onClick={closeMenu}
            >
              <div className="w-8 h-8 bg-brand-orange rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-bold">CS</span>
              </div>
              <span>Campus Secure</span>
            </Link>
            
            {/* Search Bar - Hidden on mobile */}
            <div className="hidden md:flex flex-1 max-w-md mx-8">
              <div className="relative w-full">
                <input
                  type="text"
                  placeholder="Search keyword for eg : bag , phone , wallet"
                  className="w-full bg-card border border-border rounded-lg px-4 py-2 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-brand-orange focus:border-transparent"
                />
                <button className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-brand-orange text-white px-3 py-1 rounded text-sm hover:bg-brand-orange-dark transition-colors">
                  <i className="fa-solid fa-magnifying-glass"></i>
                </button>
              </div>
            </div>
            
            {/* Hamburger Button */}
            <button
              onClick={toggleMenu}
              className="relative w-8 h-8 flex flex-col justify-center items-center space-y-1 focus:outline-none group"
              aria-label="Toggle menu"
            >
              <span 
                className={`block w-6 h-0.5 bg-foreground transition-all duration-300 ${
                  isMenuOpen ? 'rotate-45 translate-y-1.5' : ''
                }`}
              />
              <span 
                className={`block w-6 h-0.5 bg-foreground transition-all duration-300 ${
                  isMenuOpen ? 'opacity-0' : ''
                }`}
              />
              <span 
                className={`block w-6 h-0.5 bg-foreground transition-all duration-300 ${
                  isMenuOpen ? '-rotate-45 -translate-y-1.5' : ''
                }`}
              />
            </button>


          </div>
        </div>
      </nav>

      {/* Menu Overlay */}
      {isMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30"
          onClick={closeMenu}
        />
      )}

      {/* Slide-out Menu */}
      <div className={`fixed top-0 right-0 h-full w-80 bg-card shadow-2xl z-40 transform transition-transform duration-300 ease-out ${
        isMenuOpen ? 'translate-x-0' : 'translate-x-full'
      }`}>
        <div className="p-6 pt-20">
          {/* Search */}
          <div className="mb-8">
            <div className="relative">
              <input
                type="text"
                placeholder="Search items..."
                className="w-full bg-background border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-brand-orange focus:border-transparent"
              />
              <button className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-brand-orange text-white px-3 py-1 rounded text-sm hover:bg-brand-orange-dark transition-colors">
                <i className="fa-solid fa-magnifying-glass"></i>
              </button>
            </div>
          </div>

          <nav className="space-y-6">
            <Link
              to="/"
              className="block text-xl font-medium text-foreground hover:text-brand-orange transition-colors py-3 border-b border-border"
              onClick={closeMenu}
            >
              Home
            </Link>
            <Link
              to="/lost-items"
              className="block text-xl font-medium text-foreground hover:text-brand-orange transition-colors py-3 border-b border-border"
              onClick={closeMenu}
            >
              Lost Items
            </Link>
            <Link
              to="/post-found"
              className="block text-xl font-medium text-foreground hover:text-brand-orange transition-colors py-3 border-b border-border"
              onClick={closeMenu}
            >
              Post Found Item
            </Link>
            <Link
              to="/contact"
              className="block text-xl font-medium text-foreground hover:text-brand-orange transition-colors py-3 border-b border-border"
              onClick={closeMenu}
            >
              Contact Us
            </Link>
          </nav>
          
          <div className="mt-12 p-6 bg-card border border-border rounded-xl">
            <h3 className="font-semibold text-brand-orange mb-2">Need Help?</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Lost something important? We're here to help reunite you with your belongings.
            </p>
            <Link
              to="/post-found"
              className="inline-flex items-center justify-center px-4 py-2 bg-brand-orange text-white rounded-lg hover:bg-brand-orange-dark transition-colors text-sm font-medium"
              onClick={closeMenu}
            >
              Report Found Item
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}
