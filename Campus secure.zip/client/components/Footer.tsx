import { Link } from "react-router-dom";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gradient-to-br from-foreground to-foreground/90 text-white">
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="md:col-span-2">
            <Link to="/" className="text-3xl font-bold text-brand-blue mb-4 block">
              FoundIt!
            </Link>
            <p className="text-white/80 mb-6 max-w-md">
              Connecting students with their lost belongings through an easy-to-use platform. 
              Together, we make campus a more connected community.
            </p>
            <div className="flex space-x-4">
              <div className="w-10 h-10 bg-brand-blue/20 rounded-full flex items-center justify-center hover:bg-brand-blue/30 transition-colors cursor-pointer">
                <span className="text-lg">📧</span>
              </div>
              <div className="w-10 h-10 bg-brand-green/20 rounded-full flex items-center justify-center hover:bg-brand-green/30 transition-colors cursor-pointer">
                <span className="text-lg">📱</span>
              </div>
              <div className="w-10 h-10 bg-brand-purple/20 rounded-full flex items-center justify-center hover:bg-brand-purple/30 transition-colors cursor-pointer">
                <span className="text-lg">🌐</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-brand-orange">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-white/70 hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/lost-items" className="text-white/70 hover:text-white transition-colors">
                  Browse Lost Items
                </Link>
              </li>
              <li>
                <Link to="/post-found" className="text-white/70 hover:text-white transition-colors">
                  Report Found Item
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-white/70 hover:text-white transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-brand-green">Support</h3>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-white/70 hover:text-white transition-colors">
                  How It Works
                </a>
              </li>
              <li>
                <a href="#" className="text-white/70 hover:text-white transition-colors">
                  FAQ
                </a>
              </li>
              <li>
                <a href="#" className="text-white/70 hover:text-white transition-colors">
                  Safety Guidelines
                </a>
              </li>
              <li>
                <a href="#" className="text-white/70 hover:text-white transition-colors">
                  Report Issue
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Team Section */}
        <div className="mt-16 pt-8 border-t border-white/20">
          <h3 className="text-2xl font-bold text-center mb-8 text-brand-purple">Meet the Team</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="group text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-brand-blue to-brand-purple rounded-full mx-auto mb-3 flex items-center justify-center text-2xl hover:scale-110 transition-transform duration-300">
                👨‍💻
              </div>
              <h4 className="font-semibold group-hover:text-brand-blue transition-colors">Alex Chen</h4>
              <p className="text-sm text-white/60">Lead Developer</p>
            </div>
            <div className="group text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-brand-green to-brand-orange rounded-full mx-auto mb-3 flex items-center justify-center text-2xl hover:scale-110 transition-transform duration-300">
                👩‍🎨
              </div>
              <h4 className="font-semibold group-hover:text-brand-green transition-colors">Sarah Johnson</h4>
              <p className="text-sm text-white/60">UI/UX Designer</p>
            </div>
            <div className="group text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-brand-purple to-brand-blue rounded-full mx-auto mb-3 flex items-center justify-center text-2xl hover:scale-110 transition-transform duration-300">
                👨‍💼
              </div>
              <h4 className="font-semibold group-hover:text-brand-purple transition-colors">Mike Rodriguez</h4>
              <p className="text-sm text-white/60">Product Manager</p>
            </div>
            <div className="group text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-brand-orange to-brand-green rounded-full mx-auto mb-3 flex items-center justify-center text-2xl hover:scale-110 transition-transform duration-300">
                👩‍🔬
              </div>
              <h4 className="font-semibold group-hover:text-brand-orange transition-colors">Emma Davis</h4>
              <p className="text-sm text-white/60">QA Engineer</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-white/20 flex flex-col md:flex-row justify-between items-center">
          <p className="text-white/60 text-sm">
            © {currentYear} FoundIt! All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-white/60 hover:text-white text-sm transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-white/60 hover:text-white text-sm transition-colors">
              Terms of Service
            </a>
            <a href="#" className="text-white/60 hover:text-white text-sm transition-colors">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
