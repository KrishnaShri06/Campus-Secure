import { Link } from "react-router-dom";

export default function PostFoundSection() {
  return (
    <section className="py-16 bg-gradient-to-r from-brand-green/10 to-brand-blue/10">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-foreground mb-6">
            Found Something?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Help your fellow students by reporting items you've found. Every item reported increases the chance of reunion.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-brand-blue/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">📸</span>
              </div>
              <h3 className="text-lg font-semibold mb-2">Take a Photo</h3>
              <p className="text-sm text-muted-foreground">
                Snap a clear picture of the item you found
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-brand-green/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">📝</span>
              </div>
              <h3 className="text-lg font-semibold mb-2">Add Details</h3>
              <p className="text-sm text-muted-foreground">
                Describe the item and where you found it
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-brand-purple/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🤝</span>
              </div>
              <h3 className="text-lg font-semibold mb-2">Help Reunite</h3>
              <p className="text-sm text-muted-foreground">
                Connect the item with its rightful owner
              </p>
            </div>
          </div>
          
          <Link
            to="/post-found"
            className="group relative inline-flex items-center justify-center px-8 py-4 bg-gradient-to-r from-brand-green to-brand-blue text-white rounded-xl text-lg font-semibold hover:from-brand-blue hover:to-brand-purple transition-all duration-300 transform hover:scale-105 shadow-lg overflow-hidden"
          >
            <span className="relative z-10 flex items-center gap-2">
              <span>Report Found Item</span>
              <span className="text-xl">→</span>
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-brand-purple to-brand-orange opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </Link>
        </div>
      </div>
    </section>
  );
}
